package opcode;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mico
 */

import java.util.*;
import gui.frame;
import javax.swing.table.DefaultTableModel;

public class hexa extends frame{
    private static final int sizeOfIntInHalfBytes = 8;
  private static final int numberOfBitsInAHalfByte = 4;
  private static final int halfByte = 0x0F;
  private static final char[] hexDigits = { 
    '0', '1', '2', '3', '4', '5', '6', '7', 
    '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
  };

    public static void ld(String rt, String offset_base){
        System.out.println("ld instruction");
        String opc = "110111";
        ldsd(opc,offset_base.substring(offset_base.indexOf("(")+1,offset_base.indexOf(")")),rt, offset_base.substring(offset_base.indexOf(",")+1,offset_base.indexOf("(")));
    }
    
    public static void sd(String rt, String offset_base){
        System.out.println("sd instruction");
        String opc = "111111";
        ldsd(opc,offset_base.substring(offset_base.indexOf("(")+1,offset_base.indexOf(")")),rt, offset_base.substring(offset_base.indexOf(",")+1,offset_base.indexOf("(")));
    }
    
    public static void daddiu(String rs, String rt, String imm){
        System.out.println("DADDIU parameters: " + rs + rt + imm);
        String opc = "011001";
        temp(opc, rs, rt, imm);
    }
    
    public static void xori(String rs, String rt, String imm){
        System.out.println("XORI parameters: " + rs + rt + imm);
        String opc = "001110";
        temp(opc, rs, rt, imm);
    }
    
    public static void daddu(String rd, String rs, String rt){
        System.out.println("DADDU parameters: " + rd + rs + rt);
         String opc = "000000";
        tempdaddu(opc, rs, rt, rd);
    }
    
    public static void slt(String rd, String rs, String rt){
        System.out.println("SLT parameters: " + rd + rs + rt);
        String opc = "000000";
        tempslt(opc, rs, rt, rd);
    }
    
    public static void beqc(String rs, String rt, String offset){
        System.out.println("beqc instruction");
        String opc = "001000";
        tempbeq(opc,rs,rt,offset);
    }
    
    public static void jump(String target){
        System.out.println("jump instruction");
    }
    
    public static void nop(){
        System.out.println("NOP instruction");
        String opc = "000000";
        tempnop(opc);

    }
    
      // LABEL FIRST BEFORE BC, A-B, BC FIRST BEFORE LABEL, B-A
    public static String distance(String offset, ArrayList<String[]> code){
        String labelcol = offset.concat(":");
        int A=0, B=0;
        for(int i = 0; i<code.size(); i++){
            if(code.get(i)[0].compareToIgnoreCase("BC") == 0 && A == 0)
                if(code.get(i)[1].compareToIgnoreCase(offset) == 0)
                {
                    A = i;  
                }
            if(code.get(i)[0].compareToIgnoreCase(labelcol) == 0)
            {
                 B = i;
            }
    }   
            if(A>B)
                return Integer.toString(A-B);
            else
                return Integer.toString(B-A-1);
                
 }
    
    public static void dsubu(String rd, String rs, String rt){
        System.out.println("DSUBU parameters: " + rd + rs + rt);
         String opc = "000000";
        tempdsubu(opc, rs, rt, rd);
    }
    
    public static void bltc(String rs, String rt, String offset, ArrayList<String[]> code){
        String dist;
        System.out.println("beqc instruction");
        String opc = "010111";
        dist =distance(offset,code);
        tempbltc(opc,rs,rt,dist);
    }
    
    
    public static void bc(String offset, ArrayList<String[]> code){
        String dist;
        System.out.println("BC instruction");
        String opc = "110010";
        dist = distance(offset, code);
        tempbc(opc,dist);

    }
    
    
    public static String decToHex(int dec) {
    StringBuilder hexBuilder = new StringBuilder(sizeOfIntInHalfBytes);
    hexBuilder.setLength(sizeOfIntInHalfBytes);
    for (int i = sizeOfIntInHalfBytes - 1; i >= 0; --i)
    {
      int j = dec & halfByte;
      hexBuilder.setCharAt(i, hexDigits[j]);
      dec >>= numberOfBitsInAHalfByte;
    }
    return hexBuilder.toString(); 
  }
    
    
    public static String hex2Bin(String hex) {
        return String.format("%16s", Integer.toBinaryString(Integer.parseInt(hex, 16))).replace(" ", "0");
    }
    
    public static void temp(String opc, String one, String two, String three){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, r2;
        int decimal;
        r1 = one.charAt(one.length()-2);
        r2 = two.charAt(two.length()-2);
        
        stringBuilder.append(opc);
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r2).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r1).substring(2));
        stringBuilder.append((hex2Bin(three.substring(1))));
        finalString = stringBuilder.toString();
     
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        hexStr = Integer.toString(decimal,16); 
        System.out.println("Opcode: "+ hexStr);
        //DefaultTableModel model = (DefaultTableModel)(super.getJtable1());
    }
    
    
    
    public static void tempdaddu(String opc, String one, String two, String three){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, r2, r3;
        int decimal;
        r1 = one.charAt(one.length()-2);
        r2 = two.charAt(two.length()-1);
        r3 = three.charAt(three.length()-2);
        
        stringBuilder.append(opc);
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r1).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r2).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r3).substring(2));
        stringBuilder.append("00000101101");
        finalString = stringBuilder.toString();
        
       
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        hexStr = Integer.toHexString(decimal); 
        String hex = decToHex(decimal); 
        System.out.println("Opcode: "+ hex);
    }
    
    public static void ldsd(String opc, String base, String rt, String offset){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, rt2;
        int decimal;
          r1 = base.charAt(base.length()-1);
          rt2 = rt.charAt(rt.length()-2);

        
          stringBuilder.append(opc);
          stringBuilder.append("0");
          stringBuilder.append(Integer.toBinaryString(r1).substring(2));
          stringBuilder.append("0");
          stringBuilder.append(Integer.toBinaryString(rt2).substring(2));
          stringBuilder.append(hex2Bin(offset.substring(1)));
         finalString = stringBuilder.toString();
         
         String FFinal = String.format("%X", Long.parseLong(finalString,2));
     
       System.out.println("Final: "+ finalString);
   
     System.out.println("Opcode: "+ FFinal);
        
    }
    
    
    public static void tempbeq(String opc, String rs, String rt, String offset){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, r2, r3;
        int decimal;
        r1 = rs.charAt(rs.length()-2);
        r2 = rt.charAt(rt.length()-2);
        
        
        stringBuilder.append(opc);
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r1).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r2).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(hex2Bin(offset.substring(1)));
        finalString = stringBuilder.toString();
        
       
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        String hex = decToHex(decimal); 
        System.out.println("Opcode: "+ hex);
    }
    
    
    
    public static void tempslt(String opc, String one, String two, String three){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, r2, r3;
        int decimal;
        r1 = one.charAt(one.length()-2);
        r2 = two.charAt(two.length()-1);
        r3 = three.charAt(three.length()-2);
        
        stringBuilder.append(opc);
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r1).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r2).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r3).substring(2));
        stringBuilder.append("00000101010");
        finalString = stringBuilder.toString();
        
       
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        hexStr = Integer.toHexString(decimal); 
        String hex = decToHex(decimal); 
        System.out.println("Opcode: "+ hex);
    }
    
    public static void tempnop(String opc){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        int decimal;
        
        stringBuilder.append(opc);
        stringBuilder.append("00000000000000000000000000");
        finalString = stringBuilder.toString();
        
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        String hex = decToHex(decimal); 
        System.out.println("Opcode: "+ hex);
        
    }

    public static void tempdsubu(String opc, String one, String two, String three){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, r2, r3;
        int decimal;
        r1 = one.charAt(one.length()-2);
        r2 = two.charAt(two.length()-1);
        r3 = three.charAt(three.length()-2);
        
        stringBuilder.append(opc);
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r1).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r2).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r3).substring(2));
        stringBuilder.append("00000101111");
        finalString = stringBuilder.toString();
        
       
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        hexStr = Integer.toHexString(decimal); 
        String hex = decToHex(decimal); 
        System.out.println("Opcode: "+ hex);
    }
    
    
    public static void tempbltc(String opc, String rs, String rt, String distance){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        char r1, r2, r3;
        long decimal;
        r1 = rs.charAt(rs.length()-2);
        r2 = rt.charAt(rt.length()-2);
       
        stringBuilder.append(opc);
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r1).substring(2));
        stringBuilder.append("0");
        stringBuilder.append(Integer.toBinaryString(r2).substring(2));
        stringBuilder.append(hex2Bin(distance));
        finalString = stringBuilder.toString();
        
       
        System.out.println("Final: "+ finalString);
        
        decimal = Integer.parseInt(finalString,2);
        String hex = decToHex((int) decimal); 
        System.out.println("Opcode: "+ hex);
        
    }
    
    public static void tempbc(String opc, String distance){
        StringBuilder stringBuilder = new StringBuilder();
        String finalString, hexStr;
        long decimal;
        
        stringBuilder.append(opc);
        stringBuilder.append("00000");
        stringBuilder.append("00000");
        stringBuilder.append(hex2Bin(distance));
        finalString = stringBuilder.toString();
        
        System.out.println("Final: "+ finalString);
        
        decimal = Long.parseLong(finalString,2);
        String hex = decToHex((int) decimal); 
        System.out.println("Opcode: "+ hex);
    }
    
}
